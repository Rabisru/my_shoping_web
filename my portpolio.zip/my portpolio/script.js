var tabLinks = document.getElementsByClassName('tab-title-link');
var tabContents = document.getElementsByClassName('tab-content');

function openTab(tabNames) {
    for(let links of tabLinks){
        links.classList.remove('active-link')
    }
    for(let content of tabContents){
        content.classList.remove('active-tab');
    }
    event.currentTarget.classList.add('active-link')
    document.getElementById(tabNames).classList.add('active-tab');
}
 
// --------------sidebar------------

 var sidebar = document.getElementById('sidebar');

 function openMenu() {
    sidebar.style.right = '0';
 }
 function closeMenu() {
    sidebar.style.right = '-200px';
 }